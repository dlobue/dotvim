
INTRODUCTION

Cream (http://cream.sourceforge.net) is a free (GPL), easy-to-use
configuration of the powerful and famous Vim text editor for Microsoft
Windows, GNU/Linux, and FreeBSD. 

Through common menus, keyboard shortcuts, and extensive editing
functions, Cream makes Vim approachable for new users and adds
powerful features for experienced users. 

Cream is a set of scripts Vim uses to conform to the Common User
Access (CUA) standards of interface and operability, typical of most
other editors found on Microsoft, Apple, GNOME, KDE and Java
platforms. And it is all Free, licensed under the GNU General Public
License (GPL).

The goal of the project is to provide an approachable text editing
application with keyboard shortcut and menu access to Vim's full
arsenal of functionality (http://cream.sf.net/features.html). Cream
also has numerous custom extensions beyond the default Vim to meet
most editing needs.

Cream uses the Vim's own extensibility to improve editing behavior.
There are no customizations to Vim itself so you can easily try Vim
with Cream and without. Just download the one-click installer, or, if
you prefer to install it manually, the file packages for various
platforms.

Cream is a Common User Access (CUA) version of Vim. CUA was originally
a user interface standard of IBM's Systems Application Architecture,
but it now generally refers to a broad, generally accepted set of
standard Command Key-plus-letter keyboard shortcut combinations and
menu structures. Examples are found today across most applications on
the GNOME, Apple, Microsoft, KDE and Java environments. 

The project continues to develop and grow at a steady pace. Please see
the Cream web site (http://cream.sourceforge.net) for the latest
documentaton, downloads and features, and contact information if you
have questions or are interested in contributing to the effort.

Cream's name is a play on the idea of the coffee temper: Both soften
something stronger and more sophisticated, and neither can stand
alone.


SILLY TAGLINES

o Cream... because the mouse was invented in 1981

o Cream... usability for Vim

o Cream... something good to put in your Vim

o Cream... gentler till you're ready for full strength

o Cream... it takes the bitterness out

o Cream... Vim for the Emacs user in you

o Cream... a familiar feel for the famous Vim text editor

o Cream... the Vim text editor in sheep's clothing

o Cream... sheep clothing for the Vim text editor

